package coffeeshop.cofeeshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CofeeshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
